<?php session_start();?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Кинотеатр</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../../css/style.css">
</head>
<body>
<header>
    <nav class="row justify-between align-center my-3">
        <a href="../../index.php">Главная</a>
        <a href="<?php if(isset($_SESSION['user'])) echo '../../admin.php'; else echo '../../login.php'; ?>">
            Профиль
        </a>
    </nav>
</header>
<div id="content">
    <div class="container-fluid">
            <?php include '../../scripts/functions.php'; ?>
            <?php
            $pdo = getPDO();
            $id = $_GET['id'];
            if($id) {
                $image = getImageById($pdo, $id);
            }
            else {
                echo '<div class="alert alert-danger" role="alert">
                                        <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
                                          <span class="sr-only">Error:</span>
                                          Фильм не найден
                                        </div>';
            }
            ?>
            <div class="row justify-around">
                <form action="save.php" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?php echo $image['id']; ?>">
                    <div class="form-group">
                        <label for="">Фильм</label>
                        <select name="film" class="form-control" id="category">
                            <?php
                            $films = getAllFilms($pdo);
                            foreach ($films as $key => $value2) {?>
                                <option value="<?php echo $value2['film_id']; ?>" <?php if($image['film_id'] == $value2['film_id']) echo 'selected';?>>
                                    <?php echo $value2['film_name']; ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Афиша</label>
                        <input type="file" id="images" name="images" accept="image/*" required>
                    </div>
                    <button type="submit" class="btn btn-default">Сохранить</button>
                </form>
                <div class="column" style="gap: 10px;">
                    <label for="">Прошлая афиша:</label>
                    <img src="../../src/image/<?php echo $image['image_url']?>" alt="" height="450px" style="border-radius: 10px">
                </div>
            </div>
        </div>
</div>
</body>
</html>