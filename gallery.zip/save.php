<?php session_start(); ob_start();?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Кинотеатр</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../../css/style.css">
</head>
<body>
<header>
    <nav class="row justify-between align-center my-3">
        <a href="../../index.php">Главная</a>
        <a href="<?php if(isset($_SESSION['user'])) echo '../../admin.php'; else echo '../../login.php'; ?>">
            Профиль
        </a>
    </nav>
</header>
<div id="content">
    <div class="container-fluid">
            <?php include '../../scripts/functions.php'; ?>
            <?php
            $pdo = getPDO();

            if(!empty($_POST['film']) && !empty($_POST['id'])) {
                $film_id = $_POST['film'];
                $id = $_POST['id'];

                $list = ['.php', '.zip', '.js', '.html'];
                foreach ($list as $item) {
                    if(preg_match("/$item/", $_FILES['images']['name'])) {
                        exit("Расширение файла не подходит");
                    }
                }
                $type = getimagesize($_FILES['images']['tmp_name']);
                if ($type && ($type['mime'] == 'image/jpeg' || $type['mime'] == 'image/png' || $type['mime'] == 'image/jpg')) {
                    if($_FILES['images']['size'] < 1024*10000) {
                        $upload = '../../scripts/image/'.$_FILES['images']['name'];
                        if(move_uploaded_file($_FILES['images']['tmp_name'], $upload)) {
                            $images_url = $_FILES['images']['name'];

                            saveImage($pdo, $images_url, $film_id, $id);
                            header("Location: ../gallery.php");
                            ob_end_flush();
                            exit();
                        } else {
                            echo "Ошибка при загрузке";
                        }
                    } else {
                        exit("Размер файла превышен");
                    }
                } else {
                    exit("Тип файла не подходит");
                }
            }
            else {
                echo '<div class="alert alert-danger" role="alert">
                    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
                        <span class="sr-only">Error:</span>
                        Ошибка сохранения
                    </div>';
            }
            ?>
    </div>
</div>
</body>
</html>