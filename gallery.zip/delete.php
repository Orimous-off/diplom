<?php session_start();?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Кинотеатр</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../../css/style.css">
</head>
<body>
<header>
    <nav class="row justify-between align-center my-3">
        <a href="../../index.php">Главная</a>
        <a href="<?php if(isset($_SESSION['user'])) echo '../../admin.php'; else echo '../../login.php'; ?>">
            Профиль
        </a>
    </nav>
</header>
<div id="content">
    <div class="container-fluid">
            <?php include '../../scripts/functions.php'; ?>
            <?php
            $id = $_GET['id'];
            if($id) {
                $pdo = getPDO();

                deleteImage($pdo, $id);
                header("Location: ../gallery.php");
                ob_end_flush();
            } else {
                echo "<h1>Error</h1>";
                exit();
            }
            ?>
        </div>
</div>
</body>
</html>